/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication18;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author TOSHIBA
 */
public class Login {

String DBurl = "jdbc:mysql://localhost/data1";
  String DBusername = "root";
  String DBpassword = "";  
  Connection con;
  Statement stat;
  ResultSet rs;
  String sql;
            
public Login()
{
    Koneksi DB = new Koneksi();
    DB.config();
    con = DB.con;
    stat = DB.stm;
}

public void MasukkanData(ViewLogin c)
    {
        String username = c.getFusername().getText();
        String password = c.getFpassword().getText();
         try {
            sql = "SELECT * FROM login WHERE Username='"+username+"' AND Password='"+password+"'";
            rs = stat.executeQuery(sql);
            if(rs.next()){
                if(username.equals(rs.getString("Username")) && password.equals(rs.getString("Password"))){
                    //JOptionPane.showMessageDialog(null, "berhasil login");
                     new Menu().setVisible(true);
                }
            }else{
                    JOptionPane.showMessageDialog(null, "Username atau Password salah");
                }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}