/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication18;

/**
 *
 * @author TOSHIBA
 */
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*; 
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.plaf.basic.BasicSliderUI;

public class Data extends JFrame {
    JPanel panelForm, panelTombol;
    String DBurl = "jdbc:mysql://localhost/data1";
    String DBusername = "root";
    String DBpassword = "";
    Connection koneksi;
    Statement statement;
   String kelas;
   JTextField fsisa = new JTextField(10);
   JTextField fharga = new JTextField(10);

   JLabel ltanggal = new JLabel("Tanggal ");
   String[] tanggal =
            {"-Pilih Tanggal-","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31",};
   JComboBox cmbtanggal = new JComboBox(tanggal);
   JLabel lbulan = new JLabel("Bulan ");
   String[] bulan =
            {"-Pilih Bulan-"," Januari "," Februari "," Maret "," April "," Mei "," Juni "," Juli "," Agustus "," September "," Oktober "," November "," Desember ",};
   JComboBox cmbbulan = new JComboBox(bulan);
   
   JLabel ltahun = new JLabel("Tahun ");
   String[] tahun =
            {"-Pilih Tahun-","2018","2019",};
   JComboBox cmbtahun= new JComboBox(tahun);
   JLabel lHarga = new JLabel(" Harga ");
   JLabel lHarga1;
   JLabel lJudul = new JLabel(" PEMESANAN TIKET KERETA API ");
   JLabel lGambar;
//
   JRadioButton rb1 = new JRadioButton(" Eksekutif ");
   JRadioButton rb2 = new JRadioButton(" Bisnis ");
   JRadioButton rb3 = new JRadioButton(" Ekonomi ");
   JLabel lasal = new JLabel("DARI");
   String[] namaasal =
            {"Yogyakarta"};
   JComboBox cmbasal = new JComboBox(namaasal);
   JLabel ltujuan = new JLabel("TUJUAN");
   String[] namatujuan =
            {"-Pilih Tujuan-","Jakarta","Bandung","Malang","Surabaya",};
   JComboBox cmbtujuan = new JComboBox(namatujuan);
   

   JLabel lKelas = new JLabel("Kelas");
   JButton btnBeli = new JButton("Beli");
   JButton btnKembali = new JButton("");
    ControllerData controllerData;
    ModelData modelData;
   private Image image;

   public Data() {
       lHarga1 = new JLabel ("");
       cmbasal.getSelectedItem().toString();
       cmbtujuan.getSelectedItem().toString();
       cmbtanggal.getSelectedItem();
       cmbbulan.getSelectedItem();
       cmbtahun.getSelectedItem();
       
	setTitle("Pembelian Tiket Kereta Api");
	setDefaultCloseOperation(3);
        lGambar = new JLabel (new ImageIcon (getClass().getResource("image/grhpcs.jpg")));
        btnKembali = new JButton (new ImageIcon(getClass(). getResource("image/kembali.jpg")));
	setSize(750,300);
        
	ButtonGroup group = new ButtonGroup();
	group.add(rb1);
	group.add(rb2);
        group.add(rb3);

	setLayout(null);
        add(lJudul);
	add(lHarga1);
        add(lHarga);
        add(ltanggal);
        add(cmbtanggal);
        add(lbulan);
        add(cmbbulan);
        add(ltahun);
        add(cmbtahun);
	add(lKelas);
	add(rb1);
	add(rb2);
        add(rb3);
	add(lasal);
	add(cmbasal);
        add(ltujuan);
	add(cmbtujuan);
	add(btnBeli);
        add(btnKembali);
        add(lGambar);
	// setBounds(m,n,o,p)
	// m = posisi x; n = posisi n
	// o = panjang komponen; p = tinggi komponen
        lJudul.setFont(new java.awt.Font("Couture", 2, 24));
        lJudul.setForeground(Color.orange);
	lJudul.setBounds(170,2,420,40);
        lHarga.setBounds(310,190,120,20);
	lHarga1.setBounds(430,190,120,20);
        cmbtanggal.setBounds(310,160,120,20);
        ltanggal.setBounds(310,140,80,20);
        cmbbulan.setBounds(445,160,120,20);
        lbulan.setBounds(445,140,120,20);
        cmbtahun.setBounds(580,160,120,20);
        ltahun.setBounds(580,140,120,20);
	fharga.setBounds(580,190,100,20);
//	ljeniskelamin.setBounds(10,35,120,20);
//	rbPria.setBounds(130,35,100,20);
//	rbWanita.setBounds(230,35,100,20);
	lasal.setBounds(310,70,120,20);
	cmbasal.setBounds(430,70,150,20);
        ltujuan.setBounds(310,90,150,20);
	cmbtujuan.setBounds(430,90,150,20);
	lKelas.setBounds(310,115,120,20);
	rb1.setBounds(430,115,90,20);
	rb2.setBounds(530,115,80,20);
        rb3.setBounds(620,115,80,20);
	btnBeli.setBounds(400,220,120,20);
        btnKembali.setBounds(10,200,50,50);
        lGambar.setBounds(0,0,800,300);
        
	setVisible(true);
//        controllerData = new ControllerData();
//        modelData = new ModelData();
//        ControllerData.setMo(DataOrang);

        if (rb1.isSelected())
        {
           kelas=rb1.getText();
            
        }
        else if (rb2.isSelected())
        {
            kelas=rb2.getText();
        }
        else
        {
            kelas=rb3.getText();
        }
        rb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if(cmbtujuan.getSelectedItem().toString().equals("Jakarta"))
                {
                    lHarga1.setText("Rp. 450.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Bandung"))
                {
                    lHarga1.setText("Rp. 420.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Malang"))
                {
                    lHarga1.setText("Rp. 430.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Surabaya"))
                {
                    lHarga1.setText("Rp. 480.000,-");
                }
            }
        });
        rb2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if(cmbtujuan.getSelectedItem().toString().equals("Jakarta"))
                {
                    lHarga1.setText("Rp. 350.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Bandung"))
                {
                    lHarga1.setText("Rp. 320.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Malang"))
                {
                    lHarga1.setText("Rp. 330.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Surabaya"))
                {
                    lHarga1.setText("Rp. 380.000,-");
                }
            }
        });
        rb3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if(cmbtujuan.getSelectedItem().toString().equals("Jakarta"))
                {
                    lHarga1.setText("Rp. 250.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Bandung"))
                {
                    lHarga1.setText("Rp. 220.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Malang"))
                {
                    lHarga1.setText("Rp. 230.000,-");
                }
                else if(cmbtujuan.getSelectedItem().toString().equals("Surabaya"))
                {
                    lHarga1.setText("Rp. 280.000,-");
                }
            }
        });
        
        btnBeli.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                masukkanData();
                ViewData input = new ViewData(); //To change body of generated methods, choose Tools | Templates.
            }
        });
        btnKembali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                Menu m = new Menu(); //To change body of generated methods, choose Tools | Templates.
            }
        });

   }
   
   public void masukkanData() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBusername, DBpassword);
            statement = koneksi.createStatement();
            statement.executeUpdate("insert into perjalanan values('"+ cmbasal.getSelectedItem().toString() + "','" + cmbtujuan.getSelectedItem().toString() + "','" + kelas + "','" + cmbtanggal.getSelectedItem()+cmbbulan.getSelectedItem()+cmbtahun.getSelectedItem() + "','" + lHarga1.getText() + "')");
            JOptionPane.showMessageDialog(null, "Data BerhasilDisimpan!", "Hasil",JOptionPane.INFORMATION_MESSAGE);            
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Data Gagal Disimpan!", "Hasil", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan!", "Hasil", JOptionPane.ERROR_MESSAGE);
        }
    }

public static void main(String[] args) {
        new Data();
    }

}
