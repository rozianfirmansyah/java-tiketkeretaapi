/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication18;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author TOSHIBA
 */
public class Jadwal {
    String DBurl = "jdbc:mysql://localhost/data1";
    String DBusername = "root";
    String DBpassword = "";
    Connection koneksi;
    Statement statement;
    
    public void MasukkanData(InputJadwal inputJadwal)
    {
        String no_ka = inputJadwal.getFno_ka().getText();
        String nama_ka = inputJadwal.getFnama_ka().getText();
        String kelas = inputJadwal.getFkelas().getText();
        String tujuan = inputJadwal.getFtujuan().getText();
        String berangkat = inputJadwal.getFberangkat().getText();
        String tiba = inputJadwal.getFtiba().getText();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl,DBusername, DBpassword);
            statement = koneksi.createStatement();
            statement.executeUpdate("insert into jadwal values('"+ no_ka + "','" + nama_ka + "','" + kelas + "','" + tujuan+ "','" + berangkat+ "','" + tiba+ "')");
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan!", "Hasil",JOptionPane.INFORMATION_MESSAGE);            
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Data Gagal Disimpan!", "Hasil", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan!", "Hasil", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
}