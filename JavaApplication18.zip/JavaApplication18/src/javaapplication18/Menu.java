/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication18;

/**
 *
 * @author TOSHIBA
 */
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*; 
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.plaf.basic.BasicSliderUI;

public class Menu extends JFrame {
   JLabel lJudul = new JLabel(" PEMESANAN TIKET KERETA API ");
   JLabel lGambar;


   JLabel lPesan = new JLabel("Pesan Tiket");
   JLabel lJadwal = new JLabel("Jadwal Kereta Api");
   JLabel lRiwayat = new JLabel("Riwayat Perjalanan");

   JButton btnPesan = new JButton("");
   JButton btnJadwal = new JButton("");
   JButton btnRiwayat = new JButton("");

   public Menu() {
	setTitle("Pembelian Tiket Kereta Api");
	setDefaultCloseOperation(3);
        lGambar = new JLabel (new ImageIcon (getClass().getResource("image/KAI.jpg")));
        btnPesan = new JButton (new ImageIcon (getClass().getResource("image/iconk.jpg")));
        btnJadwal = new JButton (new ImageIcon (getClass().getResource("image/icon1.jpg")));
        btnRiwayat = new JButton (new ImageIcon (getClass().getResource("image/icona.png")));
	setSize(750,300);
      

	setLayout(null);
        add (lJudul);
	add(lPesan);
        add(lJadwal);
        add(lRiwayat);
	add(btnPesan);
        add(btnJadwal);
        add(btnRiwayat);
        add(lGambar);
        lJudul.setFont(new java.awt.Font("Couture", 2, 27));
        lJudul.setForeground(Color.orange);
        lPesan.setFont(new java.awt.Font("Futura Bk Bt", 2, 15));
        lJadwal.setFont(new java.awt.Font("Futura Bk Bt", 2, 15));
        lRiwayat.setFont(new java.awt.Font("Futura Bk Bt", 2, 15));
	lJudul.setBounds(130,2,480,40);
	lPesan.setBounds(90,220,120,20);
        lJadwal.setBounds(290,220,160,20);
        lRiwayat.setBounds(500,220,150,20);
	btnPesan.setBounds(100,170,50,50);
        btnJadwal.setBounds(330,170,50,50);
        btnRiwayat.setBounds(550,170,50,50);
        lGambar.setBounds(0,0,750,300);
	setVisible(true);
        btnPesan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                Data d = new Data(); //To change body of generated methods, choose Tools | Templates.
            }
        });
        btnJadwal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                LihatJadwal j = new LihatJadwal(); //To change body of generated methods, choose Tools | Templates.
            }
        });
        btnRiwayat.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                RiwayatPerjalanan r = new RiwayatPerjalanan(); //To change body of generated methods, choose Tools | Templates.
            }
        });
   }
public static void main(String[] args) {
        new Menu();
    }
}
