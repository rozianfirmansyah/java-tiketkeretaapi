/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication18;

/**
 *
 * @author TOSHIBA
 */
public class ModelJadwal {
    private String no_ka;
    private String nama_ka;
    private String kelas;
    private String tujuan;
    private String berangkat;
    private String tiba;
    private ListenerJadwal listenerJadwal;

    protected void fireOnChange() {
        if (listenerJadwal != null) {
            listenerJadwal.onChange(this);
        }
    }

    public ListenerJadwal getJadwalListener() {
        return listenerJadwal;
    }

    public void setJadwalListener(ListenerJadwal listenerJadwal) {
        this.listenerJadwal = listenerJadwal;
    }

    public String getNo_ka() {
        return no_ka;
    }

    public void setNo_ka(String no_ka) {
        this.no_ka = no_ka;
    }

    public String getNama_ka() {
        return nama_ka;
    }

    public void setNama_ka(String nama_ka) {
        this.nama_ka = nama_ka;
    }

    public String getKelas() {
        return kelas;
    }

    public void setKelas(String kelas) {
        this.kelas = kelas;
    }

    public String getTujuan() {
        return tujuan;
    }

    public void setTujuan(String tujuan) {
        this.tujuan = tujuan;
    }

    public String getBerangkat() {
        return berangkat;
    }

    public void setBerangkat(String berangkat) {
        this.berangkat = berangkat;
    }

    public String getTiba() {
        return tiba;
    }

    public void setTiba(String tiba) {
        this.tiba = tiba;
    }

    public void resetForm() {
        setNo_ka("");
        setNama_ka("");
        setKelas("");
        setTujuan("");
        setBerangkat("");
        setTiba("");
    }
    public void submitForm(InputJadwal c) {
        Jadwal d = new Jadwal();
        d.MasukkanData(c);
    }
}